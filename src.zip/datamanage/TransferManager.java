package datamanage;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.ImageIcon;

import server_manager.ClientHandler;
import server_manager.LinKlipboard;

public class TransferManager extends Thread {
	private Socket socket;
	private int dataType;
	private ClientHandler client;
	private ObjectOutputStream out;
	private ObjectInputStream in;

	public TransferManager(ClientHandler client, int dataType) {
		this.client = client;
		this.dataType = dataType;
	}

	public void setConnection() {
		try {
			String ipAddr = client.getRemoteAddr();
			int portNum = client.getRemotePort();

			// ���� ���� ����
			socket = new Socket(ipAddr, portNum);

			// ��Ʈ�� ����
			out = new ObjectOutputStream(socket.getOutputStream());
			in = new ObjectInputStream(socket.getInputStream());

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// ���� ����
		setConnection();

		// ������ ����
		try {
			switch (dataType) {
			case LinKlipboard.STRING_TYPE:
				ImageIcon receiveData = (ImageIcon) in.readObject();

				break;
			case LinKlipboard.IMAGE_TYPE:
				break;
			case LinKlipboard.FILE_TYPE:
				break;
			default:
				break;
			}
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}