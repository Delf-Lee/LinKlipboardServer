package datamanage;

import java.util.Vector;

public class History {
	private Vector<Contents> list;
}

class HistoryViewr {
	public void setViewer() {

	}
}