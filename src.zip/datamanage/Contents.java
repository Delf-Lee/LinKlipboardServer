package datamanage;

import java.util.Date;

import javax.swing.ImageIcon;

import server_manager.LinKlipboard;

public class Contents {

	protected Date date;
	protected String sharer;
	protected int type;

	public Contents(String sharer) {
		date = new Date();
		this.sharer = sharer;
	}

	public String getSharer() {
		return sharer;
	}

	public Date getDate() {
		return date;
	}
}

class SringContents extends Contents {
	private String stringData;

	public SringContents(String sharer, String data) {
		super(sharer);
		type = LinKlipboard.STRING_TYPE;
		this.stringData = data;
	}

	public String getString() {
		return stringData;
	}
}

class ImageContents extends Contents {
	private ImageIcon imageData;

	public ImageContents(String sharer, ImageIcon data) {
		super(sharer);
		type = LinKlipboard.IMAGE_TYPE;
		this.imageData = data;
	}

	public ImageIcon getImage() {
		return imageData;
	}
}

class FileContents extends Contents {
	private String filePath;

	public FileContents(String sharer, String path) {
		super(sharer);
		type = LinKlipboard.FILE_TYPE;
		this.filePath = path;
	}

	public String getfilePath() {
		return filePath;
	}
}
